#ifndef CUBE_H
#define CUBE_H

#include "shape.h"

class Cube : public Shape {
public:
  virtual void Draw ();
};
#endif